<?php
session_start();

function error($msg) {
    header('Location: index.php?error=' . urlencode($msg));
    exit;
}

if (isset($_GET['error'])) error('Acceso denegado');

if (!isset($_GET['code'], $_GET['state']) || $_GET['state'] !== ($_SESSION['state'] ?? '')) {
    error('Respuesta no válida');
}

$ch = curl_init('https://www.linkedin.com/oauth/v2/accessToken');
curl_setopt_array($ch, [
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => http_build_query([
        'grant_type'    => 'authorization_code',
        'code'          => $_GET['code'],
        'redirect_uri'  => 'http://localhost/linkedin/callback.php',
        'client_id'     => '789wmxijmkoymc',
        'client_secret' => 'WPL_AP1.sZ799xqHqVunzCBc.pQTkeg==',
    ]),
    CURLOPT_RETURNTRANSFER => true,
]);
$token = json_decode(curl_exec($ch), true);
curl_close($ch);

if (empty($token['access_token'])) error('No se pudo obtener el token');

$ch = curl_init('https://api.linkedin.com/v2/userinfo');
curl_setopt_array($ch, [
    CURLOPT_HTTPHEADER     => ['Authorization: Bearer ' . $token['access_token']],
    CURLOPT_RETURNTRANSFER => true,
]);
$user = json_decode(curl_exec($ch), true);
curl_close($ch);

if (empty($user['sub'])) error('No se pudo obtener el perfil');

$_SESSION['nombre'] = $user['name'] ?? 'Sin nombre';
$_SESSION['email']  = $user['email'] ?? 'Sin email';

header('Location: index.php');
exit;