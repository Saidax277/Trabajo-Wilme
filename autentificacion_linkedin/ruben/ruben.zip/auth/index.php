<?php session_start(); ?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="tarjeta">

    <?php if (isset($_SESSION['nombre'])): ?>

      <h1>¡Bienvenido!</h1>
      <p class="subtitulo">Sesión iniciada con LinkedIn</p>
      <div class="datos">
        <p><strong>Nombre:</strong> <?= htmlspecialchars($_SESSION['nombre']) ?></p>
        <p><strong>Email:</strong> <?= htmlspecialchars($_SESSION['email']) ?></p>
      </div>
      <a class="boton salir" href="logout.php">Cerrar sesión</a>

    <?php else: ?>

      <h1>Iniciar sesión</h1>
      <p class="subtitulo">Accede con tu cuenta de LinkedIn</p>

      <?php if (isset($_GET['error'])): ?>
        <div class="error"><?= htmlspecialchars($_GET['error']) ?></div>
      <?php endif; ?>

      <a class="boton" href="login.php">Iniciar sesión con LinkedIn</a>

    <?php endif; ?>

  </div>
</body>
</html>