<?php
session_start();

$_SESSION['state'] = bin2hex(random_bytes(16));

$url = 'https://www.linkedin.com/oauth/v2/authorization?' . http_build_query([
    'response_type' => 'code',
    'client_id'     => '789wmxijmkoymc',
    'redirect_uri'  => 'http://localhost/auth/callback.php',
    'state'         => $_SESSION['state'],
    'scope'         => 'openid profile email',
]);

header('Location: ' . $url);
exit;